/*
PROG: echo
LANG: C++
ID: hoangducv1
*/

/***
 hken - 2009-10-27
 */
#include <iostream>
#include <string>
#include <stdio.h>
#include <memory.h>

using namespace std;

int m(const string& a, const string& b)
{
	int i, j, r = 0;
	for (i=0; i<a.length(); i++) if (a[i]==b[0])
	{
		for (j=0; (i+j<a.length() && j<b.length()); j++)
			if (a[i+j] != b[j]) break;
		if (i+j<a.length()) continue;
		r = max(r, j);
	}
	return r;
}

int main()
{
	//
	freopen("echo.in", "r", stdin);
	freopen("echo.out", "w", stdout);

	//
	int res = 0;
	string a, b;
	cin >> a >> b;
	
	//
	res = max(res, m(a,b));
	res = max(res, m(b,a));
	printf("%d\n", res);
	
	return 0;
}
