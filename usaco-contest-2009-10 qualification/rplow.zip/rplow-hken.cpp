/*
PROG: rplow
LANG: C++
ID: hoangducv1
*/

/***
 hken - 2009-10-27
 */
#include <iostream>
#include <stdio.h>
#include <memory.h>

using namespace std;

int main()
{
	//
	freopen("rplow.in", "r", stdin);
	freopen("rplow.out", "w", stdout);

	//
	int row, col, n;
	int x, y, u, v;
	bool b[250][250];
	
	//
	memset(b, false, sizeof(b));
	scanf("%d%d%d", &row, &col, &n);
	for (int k=0; k<n; k++)
	{
		scanf("%d%d%d%d", &x, &y, &u, &v);
		for (int i=x; i<=u; i++) for (int j=y; j<=v; j++)
			b[i][j] = true;
	}

	//
	int res = 0;
	for (int i=1; i<=row; i++) for (int j=1; j<=col; j++)
		if (b[i][j]) res++;
	printf("%d\n", res);
	
	return 0;
}
