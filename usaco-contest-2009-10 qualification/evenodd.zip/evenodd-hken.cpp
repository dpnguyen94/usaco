/*
PROG: evenodd
LANG: C++
ID: hoangducv1
*/

/***
 hken - 2009-10-27
 */
#include <iostream>
#include <string>
#include <stdio.h>
#include <memory.h>

using namespace std;

int main()
{
	//
	freopen("evenodd.in", "r", stdin);
	freopen("evenodd.out", "w", stdout);

	//
	int numtest;
	char x[100];

	//
	scanf("%d", &numtest);
	for (int i=0; i<numtest; i++)
	{
		scanf("%s", &x);
		printf("%s\n", ((x[strlen(x)-1]&1)? "odd" : "even"));
	}
	
	return 0;
}
