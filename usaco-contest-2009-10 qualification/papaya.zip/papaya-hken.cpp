/*
PROG: papaya
LANG: C++
ID: hoangducv1
*/

/***
 hken - 2009-10-27
 */
#include <iostream>
#include <string>
#include <stdio.h>
#include <memory.h>

using namespace std;

const int xx[] = {-1, 0, 1, 0};
const int yy[] = { 0, 1, 0,-1};

int row, col, res;
int a[50][50];


void input()
{
	//
	scanf("%d%d", &row, &col);

	//
	memset(a, 0, sizeof(a));
	for (int i=1; i<=row; i++) for (int j=1; j<=col; j++)
		scanf("%d", &a[i][j]);
}

void process()
{
	int x=1, y=1, sx=0, sy=0, newx, newy, mm;

	do {
		//
		res += a[x][y];
		a[x][y] = 0;
		if (x==row && y==col) break;

		//
		mm = 0;
		for (int k=0; k<4; k++)
		{
			newx = x+xx[k], newy = y+yy[k];
			if (mm < a[newx][newy]) mm=a[newx][newy], sx=newx, sy=newy;
		}
		if (mm==0) break;

		//
		x = sx, y = sy;
	} while (1);
}

int main()
{
	//
	freopen("papaya.in", "r", stdin);
	freopen("papaya.out", "w", stdout);

	//
	input();
	process();
	printf("%d\n", res);
	
	return 0;
}
