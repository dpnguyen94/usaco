/*
PROG: milkweed
LANG: C++
ID: hoangducv1
*/

/***
 hken - 2009-10-27
 */
#include <iostream>
#include <string>
#include <queue>
#include <algorithm>
#include <stdio.h>
#include <memory.h>

using namespace std;

const int xx[] = {-1,-1, 0, 1, 1, 1, 0,-1};
const int yy[] = { 0, 1, 1, 1, 0,-1,-1,-1};

int row, col, x, y, res;
char a[110][110];
int  c[110][110];


void input()
{
	//
	scanf("%d%d%d%d", &col, &row, &y, &x);
	x = row + 1 - x;

	//
	for (int i=1; i<=row; i++) scanf("%s", &a[i][1]);
	for (int i=0; i<=col+1; i++) a[0][i] = a[row+1][i] = '*';
	for (int i=0; i<=row+1; i++) a[i][0] = a[i][col+1] = '*';
}


void process()
{
	int nx, ny;
	queue<int> qx, qy;

	//
	memset(c, -1, sizeof(c));
	c[x][y] = 0;
	qx.push(x); qy.push(y);

	//
	while (!qx.empty())
	{
		//
		x = qx.front(); y = qy.front();
		qx.pop(); qy.pop();

		//
		for (int k=0; k<8; k++)
		{
			nx = x+xx[k], ny = y+yy[k];
			if (a[nx][ny]=='*' || c[nx][ny]!=-1) continue;

			c[nx][ny] = c[x][y]+1;
			qx.push(nx); qy.push(ny);
		}
	}

	//for (int i=1; i<=row; i++) { for (int j=1; j<=col; j++) printf("%4d", c[i][j]); printf("\n"); }

	//
	res = 0;
	for (int i=1; i<=row; i++) for (int j=1; j<=col; j++)
		if (res < c[i][j]) res = c[i][j];
}

int main()
{
	//
	freopen("milkweed.in", "r", stdin);
	freopen("milkweed.out", "w", stdout);

	//
	input();
	process();
	printf("%d\n", res);
	
	return 0;
}
