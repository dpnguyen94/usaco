/*
PROG: stroll
LANG: C++
ID: hoangducv1
*/

/***
 hken - 2009-10-27
 */
#include <iostream>
#include <string>
#include <stdio.h>
#include <memory.h>

using namespace std;

int n, res;
int a[1000][2], c[1000];


void input()
{
	int x, y, z;

	scanf("%d", &n);
	for (int i=0; i<n-1; i++)
	{
		scanf("%d%d%d", &x, &y, &z);
		a[x-1][0] = y-1;
		a[x-1][1] = z-1;
	}
}

void t(int x)
{
	//
	int& y = a[x][0];
	if (y != -1) { c[y] = c[x]+1; t(y); }

	//
	int& z = a[x][1];
	if (z != -1) { c[z] = c[x]+1; t(z); }
}

void process()
{
	//
	if (n == 1) { res = 0; return; }

	//
	c[0] = 1;
	t(0);

	//
	res = 0;
	for (int i=0; i<n-1; i++) res = max(res, c[i]);
}

int main()
{
	//
	freopen("stroll.in", "r", stdin);
	freopen("stroll.out", "w", stdout);

	//
	input();
	process();
	printf("%d\n", res);
	
	return 0;
}
